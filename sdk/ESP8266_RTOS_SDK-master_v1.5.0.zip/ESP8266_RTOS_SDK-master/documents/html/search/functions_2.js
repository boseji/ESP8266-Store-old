var searchData=
[
  ['gpio16_5finput_5fconf',['gpio16_input_conf',['../group__GPIO__Driver__APIs.html#gacc7e5be6c1aed84fe3c3260deea64a3e',1,'gpio.h']]],
  ['gpio16_5finput_5fget',['gpio16_input_get',['../group__GPIO__Driver__APIs.html#ga4484530a542760c430ebb2e754b6e621',1,'gpio.h']]],
  ['gpio16_5foutput_5fconf',['gpio16_output_conf',['../group__GPIO__Driver__APIs.html#gaf94c9f201c7ee9ad7a71b5eb8b720b00',1,'gpio.h']]],
  ['gpio16_5foutput_5fset',['gpio16_output_set',['../group__GPIO__Driver__APIs.html#ga4f83a12f673ab6e664c6ea129a1ca9c2',1,'gpio.h']]],
  ['gpio_5finput_5fget',['gpio_input_get',['../group__GPIO__Driver__APIs.html#ga678824698fa5936b7928c24c6cfd0a17',1,'gpio.h']]],
  ['gpio_5fintr_5fhandler_5fregister',['gpio_intr_handler_register',['../group__GPIO__Driver__APIs.html#ga7b94b7d43c84a8177f4301b6a001fae3',1,'gpio.h']]],
  ['gpio_5foutput_5fconf',['gpio_output_conf',['../group__GPIO__Driver__APIs.html#gad57551861ccb3b7f4d16c0de00717e29',1,'gpio.h']]],
  ['gpio_5fpin_5fintr_5fstate_5fset',['gpio_pin_intr_state_set',['../group__GPIO__Driver__APIs.html#ga0adef8a3e9d5c302d96d1ddc360f7c79',1,'gpio.h']]],
  ['gpio_5fpin_5fwakeup_5fdisable',['gpio_pin_wakeup_disable',['../group__GPIO__Driver__APIs.html#gaffbe088057472f44ddf99c7912f54300',1,'gpio.h']]],
  ['gpio_5fpin_5fwakeup_5fenable',['gpio_pin_wakeup_enable',['../group__GPIO__Driver__APIs.html#gae37bc72b183440f9733f14df516cee7b',1,'gpio.h']]]
];
