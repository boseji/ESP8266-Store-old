#ifndef _OPENSSL_DEMO_H_
#define _OPENSSL_DEMO_H_

void user_conn_init(void);

#endif
