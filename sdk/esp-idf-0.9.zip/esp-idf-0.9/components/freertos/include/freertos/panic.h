#ifndef PANIC_H
#define PANIC_H

void setBreakpointIfJtag(void *fn);


#endif