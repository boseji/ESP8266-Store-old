var searchData=
[
  ['force_20sleep_20apis',['Force Sleep APIs',['../group__WiFi__Force__Sleep__APIs.html',1,'']]]
];
