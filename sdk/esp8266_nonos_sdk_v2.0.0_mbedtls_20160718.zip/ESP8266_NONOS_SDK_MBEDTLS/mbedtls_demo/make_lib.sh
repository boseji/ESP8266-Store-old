#!/bin/bash -x

echo "make_lib.sh version 20160623"
echo ""

cd $1
make clean
make COMPILE=gcc

# Make sure the lib folder is exist.

cp .output/eagle/debug/lib/lib$1.a ../../lib/lib$1.a
xtensa-lx106-elf-strip --strip-unneeded ../../lib/lib$1.a
cd ..
