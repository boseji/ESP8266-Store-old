1. 特性
1.1. 支持TLS1.0，TLS1.1，TLS1.2，不支持SSL3.0
1.2. TLS 缓存范围2048~8192
1.3. 支持AES128,AES256加密算法，CBC模式
1.4. 支持SHA1,SHA256，SHA384，SHA512哈希算法
1.5. 支持RSA512，RSA1024，RSA2048秘钥算法
1.6. 支持PEM,DER格式证书
1.7. 支持单向认证，双向认证
1.8. 支持三级证书链解析
1.9. 不支持使用root证书验证三级证书链

2. 使用
2.1. 如ESP8266_NONOS_SDK版本低于2.0.0，请将ESP8266_NONOS_SDK_EMBEDTLS目录下的include、ld、lib文件夹拷贝到SDK根目录进行覆盖；高版本的，只需拷贝lib目录
2.2. 如用户之前已采用libssl.a，则可修改用户工程目录下的Makefile，将“-lssl”修改为"-lmbedtls"，用户代码不需做任何修改
2.3. mbedtls_demo示例包含了mbedtls源码、espconn_secure_xxxx接口具体实现，以及一个简单示例。
    2.3.1.将mbedtls_demo整个文件夹拷贝到SDK根目录
    2.3.2.进入mbedtls_demo目录，执行命令 ./make_lib.sh mbedtls ，会自动编译mbedtls源码生成libmbedtls.a，并拷贝该库到SDK/lib目录
    2.3.3.通过 ./gen_misc.sh 可生成该demo的测试固件
—————————————————————————————————————————————————————————————————————————————————————

1. Features
1.1. Supports TLS 1.0, TLS 1.1, TLS 1.2, doesn’t support SSL 3.0.
1.2. TLS cache of 2048 to 8192 bytes.
1.3. Supports  AES-128 and AES-256 encryption algorithm, and CBC mode.
1.4. Supports SHA-1, SHA-256, SHA-384 and SHA-512 hash algorithm.
1.5. Supports RSA-512, RSA-1024, RSA-2048 algorithm.
1.6. Supports certificates in PEM format and DER format.
1.7. Supports both unidirectional authentication and bidirectional authentication.
1.8. Supports three-tier certificate chain parsing.
1.9. Doesn’t support verify three-tier certificate chain with root certificate.

2. Usage
2.1. For ESP8266_NONOS_SDK versions older than 2.0.0, copy include, ld and lib folders in the directory of ESP8266_NONOS_SDK_EMBEDTLS to SDK root directory. For version 2.0.0 and later, only the lib folder needs to be copied.
2.2. “-lssl” in Makefile of user’s project directory should be modified into “-lmbedtls” if the user has utilized libssl.a before. There is no need to modify any user code.
2.3. mbedtls_demo includes source code of mbedtls, espconn_secure_xxxx APIs and a simple example.
2.3.1. Copy the entire folder of mbedtls_demoto the SDK root directory.
    2.3.2. Find and run "./make_lib.sh mbedtls" in mbedtls_demo directory. Source code of mbedtls will be automatically compiled and generate libmbedtls.a which will be copied to SDK/lib directory.
    2.3.3. Test firmware of mbedtls_demo can be generated via ./gen_misc.sh.