var searchData=
[
  ['temperature_5fsensor_5fread',['temperature_sensor_read',['../group___sensor___a_p_is.html#gaa2a79044390ed33f58e9f0bdb8223291',1,'esp_sensor.h']]],
  ['tentative',['TENTATIVE',['../group__system__upgrade___a_p_is.html#ggadf764cbdea00d65edcd07bb9953ad2b7a661b0215f708ebf8454810da5c4fe2e5',1,'upgrade.h']]],
  ['touch_5fsensor_5finit',['touch_sensor_init',['../group___sensor___a_p_is.html#ga5ac5955f365a20e4e2c7f544784c8484',1,'esp_sensor.h']]],
  ['touch_5fsensor_5fread',['touch_sensor_read',['../group___sensor___a_p_is.html#gab911c86b2499ccd184db0e5d996295e9',1,'esp_sensor.h']]]
];
