var searchData=
[
  ['flash_5fid_5fnum',['flash_id_num',['../structremote__bin__info.html#aa2315c9cf8e0a90275fa3c3a6b16b570',1,'remote_bin_info']]],
  ['freq_5foffset',['freq_offset',['../structbss__info.html#abc41a63643b5fa7974868e1972d2675c',1,'bss_info']]]
];
