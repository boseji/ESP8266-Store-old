var searchData=
[
  ['upgrade_5fflag',['upgrade_flag',['../structupgrade__info.html#afba04a7feb34e4f63adf66255f2bf502',1,'upgrade_info']]]
];
