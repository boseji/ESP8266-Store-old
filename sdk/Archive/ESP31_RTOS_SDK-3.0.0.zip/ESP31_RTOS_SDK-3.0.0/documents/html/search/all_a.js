var searchData=
[
  ['jump_5faddr',['jump_addr',['../structb__info.html#a91f117e90ded426d8996ff12da7b7c57',1,'b_info']]]
];
