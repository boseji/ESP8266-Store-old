var searchData=
[
  ['regdomain_5fchan',['regdomain_chan',['../structregdomain__info_1_1regdomain__chan.html',1,'regdomain_info']]],
  ['regdomain_5finfo',['regdomain_info',['../structregdomain__info.html',1,'']]],
  ['remote_5fbin_5finfo',['remote_bin_info',['../structremote__bin__info.html',1,'']]]
];
