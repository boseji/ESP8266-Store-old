var searchData=
[
  ['i2s_5fgpio_5finit',['i2s_GPIO_init',['../group___i2_s___driver___a_p_is.html#gada1e66e888bcbacbe4ed1e6e1173c7b7',1,'i2s.h']]],
  ['i2s_5finit',['i2s_init',['../group___i2_s___driver___a_p_is.html#ga73ce4945fabc9a4bb717a57ea4bdfd17',1,'i2s.h']]],
  ['i2s_5ftest',['i2s_test',['../group___i2_s___driver___a_p_is.html#ga0454c35f4c64068358b516aba1a72a05',1,'i2s.h']]],
  ['intr_5fmatrix_5fset',['intr_matrix_set',['../group___g_p_i_o___driver___a_p_is.html#gabbd02e0f7a466f67c876b6dcd1a9e96a',1,'gpio.h']]]
];
