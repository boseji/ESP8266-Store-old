# HOWTO #
run:
./make_lib.sh driver
libdriver.a will be generated in $SDK_PATH/lib