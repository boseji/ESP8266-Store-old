var searchData=
[
  ['bin_5fmagic_5ferror',['BIN_MAGIC_ERROR',['../group__system__upgrade___a_p_is.html#gga1e8876da5916ec8c91b126453fad76f9a3d6ef791fc901d480a1d98c1c04534eb',1,'upgrade.h']]],
  ['bt_5fmac',['BT_MAC',['../group___hardware___m_a_c___a_p_is.html#gga592f873b2a2cd40e54795a1b27e6bf9dab8fd5f1df2266848b72d652a43433f2c',1,'esp_system.h']]]
];
