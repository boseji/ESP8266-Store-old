var searchData=
[
  ['crc_5fcheck_5ffailed_5ferror',['CRC_CHECK_FAILED_ERROR',['../group__system__upgrade___a_p_is.html#gga1e8876da5916ec8c91b126453fad76f9a53a63fb485ab084c646156d61a29eb2a',1,'upgrade.h']]],
  ['create_5fsocket_5ferror',['CREATE_SOCKET_ERROR',['../group__system__upgrade___a_p_is.html#gga1e8876da5916ec8c91b126453fad76f9a35d0b1dbf7edc008ed05a0eba325d6b3',1,'upgrade.h']]]
];
