# ESP-Tuning User Guide

[ESP-Tuning Tool user](https://github.com/espressif/esp-iot-solution/blob/master/documents/touch_pad_solution/esp_tuning_tool_user_guide_en.md)

## Software version

Release v1.0 .
